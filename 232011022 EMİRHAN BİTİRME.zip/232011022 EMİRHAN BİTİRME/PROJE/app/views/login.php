<?php
// Database connection
$servername = "sql306.infinityfree.com";
$username = "if0_38450132";
$password = "wXMyg7Q6Hhkz"; 
$dbname = "if0_38450132_yeni";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$conn->set_charset("utf8");

// Initialize variables
$username = $isim = $soyisim = $email = $password = $il_id = $ilce_id = "";
$username_err = $isim_err = $soyisim_err = $email_err = $password_err = $login_err = $registration_success = "";
$il_err = $ilce_err = ""; // İl ve ilçe hata mesajları için yeni değişkenler

// Processing form data when form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    
    // Check if it's a login or registration attempt
    if (isset($_POST["login"])) {
        // Login Process
        
        // Validate email
        if (empty(trim($_POST["email"]))) {
            $email_err = "Lütfen e-posta adresinizi girin.";
        } else {
            $email = trim($_POST["email"]);
        }
        
        // Validate password
        if (empty(trim($_POST["password"]))) {
            $password_err = "Lütfen şifrenizi girin.";
        } else {
            $password = trim($_POST["password"]);
        }
        
        // Check input errors before querying the database
        if (empty($email_err) && empty($password_err)) {
            // Prepare a select statement
            $sql = "SELECT id, username, isim, soyisim, email, sifre FROM users WHERE email = ?";
            
            if ($stmt = $conn->prepare($sql)) {
                // Bind variables to the prepared statement as parameters
                $stmt->bind_param("s", $param_email);
                
                // Set parameters
                $param_email = $email;
                
                // Attempt to execute the prepared statement
                if ($stmt->execute()) {
                    // Store result
                    $stmt->store_result();
                    
                    // Check if email exists, if yes then verify password
                    if ($stmt->num_rows == 1) {                    
                        // Bind result variables
                        $stmt->bind_result($id, $db_username, $db_isim, $db_soyisim, $db_email, $hashed_password);
                        if ($stmt->fetch()) {
                            if (password_verify($password, $hashed_password)) {
                                // Password is correct, start a new session
                                session_start();
                                
                                // Store data in session variables
                                $_SESSION["loggedin"] = true;
                                $_SESSION["id"] = $id;
                                $_SESSION["username"] = $db_username;
                                $_SESSION["isim"] = $db_isim;
                                $_SESSION["soyisim"] = $db_soyisim;
                                
                                // Redirect user to welcome page
                                header("location: index.php");
                                exit();
                            } else {
                                // Password is not valid
                                $login_err = "Geçersiz e-posta veya şifre.";
                            }
                        }
                    } else {
                        // Email doesn't exist
                        $login_err = "Geçersiz e-posta veya şifre.";
                    }
                } else {
                    echo "Oops! Bir hata oluştu. Lütfen daha sonra tekrar deneyin.";
                }

                // Close statement
                $stmt->close();
            }
        }
        
    } elseif (isset($_POST["register"])) {
        // Registration Process
        
        // Validate username
        if (empty(trim($_POST["username"]))) {
            $username_err = "Lütfen bir kullanıcı adı girin.";
        } else {
            // Prepare a select statement
            $sql = "SELECT id FROM users WHERE username = ?";
            
            if ($stmt = $conn->prepare($sql)) {
                $stmt->bind_param("s", $param_username);
                $param_username = trim($_POST["username"]);
                
                if ($stmt->execute()) {
                    $stmt->store_result();
                    
                    if ($stmt->num_rows == 1) {
                        $username_err = "Bu kullanıcı adı zaten alınmış.";
                    } else {
                        $username = trim($_POST["username"]);
                    }
                }
                $stmt->close();
            }
        }
        
        // Validate isim
        if (empty(trim($_POST["isim"]))) {
            $isim_err = "Lütfen adınızı girin.";
        } else {
            $isim = trim($_POST["isim"]);
        }
        
        // Validate soyisim
        if (empty(trim($_POST["soyisim"]))) {
            $soyisim_err = "Lütfen soyadınızı girin.";
        } else {
            $soyisim = trim($_POST["soyisim"]);
        }
        
        // Validate email
        if (empty(trim($_POST["email"]))) {
            $email_err = "Lütfen bir e-posta adresi girin.";
        } else {
            if (!filter_var(trim($_POST["email"]), FILTER_VALIDATE_EMAIL)) {
                $email_err = "Geçerli bir e-posta adresi girin.";
            } else {
                $sql = "SELECT id FROM users WHERE email = ?";
                if ($stmt = $conn->prepare($sql)) {
                    $stmt->bind_param("s", $param_email);
                    $param_email = trim($_POST["email"]);
                    
                    if ($stmt->execute()) {
                        $stmt->store_result();
                        
                        if ($stmt->num_rows == 1) {
                            $email_err = "Bu e-posta adresi zaten kayıtlı.";
                        } else {
                            $email = trim($_POST["email"]);
                        }
                    }
                    $stmt->close();
                }
            }
        }
        
        // Validate password
        if (empty(trim($_POST["password"]))) {
            $password_err = "Lütfen bir şifre girin.";     
        } elseif (strlen(trim($_POST["password"])) < 6) {
            $password_err = "Şifre en az 6 karakter olmalıdır.";
        } else {
            $password = trim($_POST["password"]);
        }
        
        // Validate il and ilce
        if (empty($_POST["il_id"])) {
            $il_err = "Lütfen bir il seçin.";
        } else {
            $il_id = $_POST["il_id"];
        }
        
        if (empty($_POST["ilce_id"])) {
            $ilce_err = "Lütfen bir ilçe seçin.";
        } else {
            $ilce_id = $_POST["ilce_id"];
        }
        
        // Check input errors before inserting in database
        if (empty($username_err) && empty($email_err) && empty($password_err) && empty($isim_err) && empty($soyisim_err) && empty($il_err) && empty($ilce_err)) {
            
            // Prepare an insert statement
            $sql = "INSERT INTO users (username, isim, soyisim, email, sifre, il_id, ilce_id) VALUES (?, ?, ?, ?, ?, ?, ?)";
             
            if ($stmt = $conn->prepare($sql)) {
                // Bind variables to the prepared statement as parameters
                $stmt->bind_param("sssssii", $param_username, $param_isim, $param_soyisim, $param_email, $param_password, $param_il_id, $param_ilce_id);
                
                // Set parameters
                $param_username = $username;
                $param_isim = $isim;
                $param_soyisim = $soyisim;
                $param_email = $email;
                $param_password = password_hash($password, PASSWORD_DEFAULT);
                $param_il_id = $il_id;
                $param_ilce_id = $ilce_id;
                
                // Attempt to execute the prepared statement
                if ($stmt->execute()) {
                    // Registration successful
                    $registration_success = "Kayıt başarılı! Şimdi giriş yapabilirsiniz.";
                } else {
                    echo "Oops! Bir hata oluştu. Lütfen daha sonra tekrar deneyin.";
                }

                // Close statement
                $stmt->close();
            }
        }
    }
}

// Get iller for dropdown
function getIller($conn) {
    $sql = "SELECT il_id, il_adi FROM iller ORDER BY il_adi";
    $result = $conn->query($sql);
    $iller = array();
    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $iller[] = $row;
        }
    }
    return $iller;
}

// Get ilceler for dropdown
function getIlceler($conn, $il_id) {
    $sql = "SELECT ilce_id, ilce_adi FROM ilceler WHERE il_id = ? ORDER BY ilce_adi";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $il_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $ilceler = array();
    while($row = $result->fetch_assoc()) {
        $ilceler[] = $row;
    }
    $stmt->close();
    return $ilceler;
}
?>

<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Giriş Yap / Kaydol - Sarsilmaz</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        
        body {
            background-color: #f5f5f5;
        }
        
        .container {
            max-width: 1000px;
            margin: 50px auto;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        
        .logo {
            margin-bottom: 30px;
        }
        
        .logo img {
            height: 40px;
        }
        
        .tabs {
            display: flex;
            width: 100%;
            max-width: 400px;
            margin-bottom: 20px;
        }
        
        .tab {
            flex: 1;
            text-align: center;
            padding: 15px;
            background-color: #eee;
            cursor: pointer;
            font-weight: bold;
            transition: background-color 0.3s;
        }
        
        .tab.active {
            background-color: #234687;
            color: white;
        }
        
        .form-container {
            width: 100%;
            max-width: 400px;
            background-color: white;
            padding: 30px;
            border-radius: 8px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
        }
        
        .form-group {
            margin-bottom: 20px;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 500;
        }
        
        .form-control {
            width: 100%;
            padding: 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
            font-size: 16px;
        }
        
        .form-control:focus {
            border-color: #234687;
            outline: none;
        }
        
        .invalid-feedback {
            color: #E5141D;
            font-size: 14px;
            margin-top: 5px;
        }
        
        .success-message {
            color: #28a745;
            font-size: 14px;
            margin-bottom: 15px;
        }
        
        .btn {
            width: 100%;
            padding: 12px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        
        .btn-primary {
            background-color: #234687;
            color: white;
        }
        
        .btn-primary:hover {
            background-color: #1a3567;
        }
        
        .btn-danger {
            background-color: #E5141D;
            color: white;
        }
        
        .btn-danger:hover {
            background-color: #c41319;
        }
        
        .back-link {
            margin-top: 20px;
            text-align: center;
        }
        
        .back-link a {
            color: #234687;
            text-decoration: none;
        }
        
        .back-link a:hover {
            text-decoration: underline;
        }
        
        #login-form, #register-form {
            display: none;
        }
        
        .form-active {
            display: block !important;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="logo">
            <a href="index.php"><img src="http://emirsabanci.rf.gd/sarsilmaz/img/logo.png" alt="Sarsilmaz"></a>
        </div>
        
        <div class="tabs">
            <div class="tab active" id="login-tab">Giriş Yap</div>
            <div class="tab" id="register-tab">Kaydol</div>
        </div>
        
        <div class="form-container">
            <!-- Login Form -->
            <form id="login-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post" class="form-active">
                <?php 
                if(!empty($login_err)){
                    echo '<div class="invalid-feedback">' . $login_err . '</div>';
                }
                if(!empty($registration_success)){
                    echo '<div class="success-message">' . $registration_success . '</div>';
                }
                ?>
                
                <div class="form-group">
                    <label>E-posta</label>
                    <input type="email" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                    <span class="invalid-feedback"><?php echo $email_err; ?></span>
                </div>
                
                <div class="form-group">
                    <label>Şifre</label>
                    <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                    <span class="invalid-feedback"><?php echo $password_err; ?></span>
                </div>
                
                <div class="form-group">
                    <button type="submit" name="login" class="btn btn-primary">Giriş Yap</button>
                </div>
            </form>
            
            <!-- Registration Form -->
            <form id="register-form" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                <div class="form-group">
                    <label>Kullanıcı Adı</label>
                    <input type="text" name="username" class="form-control <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $username; ?>">
                    <span class="invalid-feedback"><?php echo $username_err; ?></span>
                </div>

                <div class="form-group">
                    <label>Ad</label>
                    <input type="text" name="isim" class="form-control <?php echo (!empty($isim_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $isim; ?>">
                    <span class="invalid-feedback"><?php echo $isim_err; ?></span>
                </div>

                <div class="form-group">
                    <label>Soyad</label>
                    <input type="text" name="soyisim" class="form-control <?php echo (!empty($soyisim_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $soyisim; ?>">
                    <span class="invalid-feedback"><?php echo $soyisim_err; ?></span>
                </div>
                
                <div class="form-group">
                    <label>E-posta</label>
                    <input type="email" name="email" class="form-control <?php echo (!empty($email_err)) ? 'is-invalid' : ''; ?>" value="<?php echo $email; ?>">
                    <span class="invalid-feedback"><?php echo $email_err; ?></span>
                </div>
                
                <div class="form-group">
                    <label>Şifre</label>
                    <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                    <span class="invalid-feedback"><?php echo $password_err; ?></span>
                </div>

                <div class="form-group">
                    <label>İl</label>
                    <select name="il_id" id="il_id" class="form-control <?php echo (!empty($il_err)) ? 'is-invalid' : ''; ?>">
                        <option value="">İl Seçiniz</option>
                        <?php
                        $iller = getIller($conn);
                        foreach($iller as $il) {
                            $selected = ($il_id == $il['il_id']) ? 'selected' : '';
                            echo '<option value="'.$il['il_id'].'" '.$selected.'>'.$il['il_adi'].'</option>';
                        }
                        ?>
                    </select>
                    <span class="invalid-feedback"><?php echo $il_err; ?></span>
                </div>

                <div class="form-group">
                    <label>İlçe</label>
                    <select name="ilce_id" id="ilce_id" class="form-control <?php echo (!empty($ilce_err)) ? 'is-invalid' : ''; ?>">
                        <option value="">Önce İl Seçiniz</option>
                        <?php
                        if(!empty($il_id)) {
                            $ilceler = getIlceler($conn, $il_id);
                            foreach($ilceler as $ilce) {
                                $selected = ($ilce_id == $ilce['ilce_id']) ? 'selected' : '';
                                echo '<option value="'.$ilce['ilce_id'].'" '.$selected.'>'.$ilce['ilce_adi'].'</option>';
                            }
                        }
                        ?>
                    </select>
                    <span class="invalid-feedback"><?php echo $ilce_err; ?></span>
                </div>
                
                <div class="form-group">
                    <button type="submit" name="register" class="btn btn-danger">Kaydol</button>
                </div>
            </form>
        </div>
        
        <div class="back-link">
            <a href="index.php">Ana Sayfaya Dön</a>
        </div>
    </div>
    
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const loginTab = document.getElementById('login-tab');
            const registerTab = document.getElementById('register-tab');
            const loginForm = document.getElementById('login-form');
            const registerForm = document.getElementById('register-form');
            
            // Tab switching logic
            loginTab.addEventListener('click', function() {
                loginTab.classList.add('active');
                registerTab.classList.remove('active');
                loginForm.classList.add('form-active');
                registerForm.classList.remove('form-active');
            });
            
            registerTab.addEventListener('click', function() {
                registerTab.classList.add('active');
                loginTab.classList.remove('active');
                registerForm.classList.add('form-active');
                loginForm.classList.remove('form-active');
            });
            
            // İl-İlçe seçimi
            document.getElementById('il_id').addEventListener('change', function() {
                var il_id = this.value;
                var ilce_select = document.getElementById('ilce_id');
                
                // İlçe seçimini temizle
                ilce_select.innerHTML = '<option value="">İlçe Seçiniz</option>';
                
                if(il_id) {
                    // AJAX ile ilçeleri getir
                    fetch('get_ilceler.php?il_id=' + il_id)
                        .then(response => {
                            if (!response.ok) {
                                throw new Error('İlçeler getirilemedi.');
                            }
                            return response.json();
                        })
                        .then(data => {
                            if(data && data.length > 0) {
                                data.forEach(function(ilce) {
                                    var option = document.createElement('option');
                                    option.value = ilce.ilce_id;
                                    option.textContent = ilce.ilce_adi;
                                    ilce_select.appendChild(option);
                                });
                            } else {
                                ilce_select.innerHTML = '<option value="">Bu ile ait ilçe bulunamadı</option>';
                            }
                        })
                        .catch(error => {
                            console.error('Error:', error);
                            ilce_select.innerHTML = '<option value="">Hata: İlçeler yüklenemedi</option>';
                        });
                }
            });
            
            // Form gönderilmeden önce ilçenin seçildiğini kontrol et
            document.querySelector('form[name="register-form"]')?.addEventListener('submit', function(e) {
                var ilce_select = document.getElementById('ilce_id');
                if (!ilce_select.value) {
                    e.preventDefault();
                    alert('Lütfen bir ilçe seçin.');
                    return false;
                }
            });
            
            // If there was a registration success, make sure login tab is active
            <?php if(!empty($registration_success)): ?>
            loginTab.click();
            <?php endif; ?>
            
            // If there was a registration error, make sure register tab is active
            <?php if(!empty($username_err) || !empty($email_err) || !empty($password_err) || !empty($isim_err) || !empty($soyisim_err) || !empty($il_err) || !empty($ilce_err)): ?>
            <?php if(isset($_POST["register"])): ?>
            registerTab.click();
            <?php endif; ?>
            <?php endif; ?>
            
            // Eğer il seçili ise, ilçeleri yükle
            <?php if(!empty($il_id)): ?>
            var il_select = document.getElementById('il_id');
            if(il_select.value) {
                il_select.dispatchEvent(new Event('change'));
            }
            <?php endif; ?>
        });
    </script>
</body>
</html>