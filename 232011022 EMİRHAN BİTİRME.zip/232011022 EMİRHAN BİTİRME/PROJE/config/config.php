<?php
// Database configuration
$servername = "sql306.infinityfree.com";
$username = "if0_38450132";
$password = "wXMyg7Q6Hhkz"; 
$dbname = "if0_38450132_yeni";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Set charset to UTF-8
$conn->set_charset("utf8");

// Check connection
if ($conn->connect_error) {
    die("Veritabanı bağlantısı başarısız: " . $conn->connect_error);
}
?>