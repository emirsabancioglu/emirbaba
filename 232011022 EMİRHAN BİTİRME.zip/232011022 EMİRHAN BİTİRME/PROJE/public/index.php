<?php
// Start the session
session_start();

// Veritabanı bağlantısını ekleme
require_once 'config.php';

// Check if the user is logged in
$isLoggedIn = isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true;

// Initialize cart in session if it doesn't exist
if (!isset($_SESSION['cart'])) {
    $_SESSION['cart'] = array();
    $_SESSION['cart_total'] = 0;
}

// Initialize favorites in session if it doesn't exist
if (!isset($_SESSION['favorites'])) {
    $_SESSION['favorites'] = array();
    $_SESSION['favorites_count'] = 0;
}

// Sepete ürün ekleme işlemi
if(isset($_POST['add_to_cart'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_POST['product_image'];
    
    // Ürün sepette var mı kontrol et
    if(isset($_SESSION['cart'][$product_id])) {
        // Ürün sepette varsa miktarını artır
        $_SESSION['cart'][$product_id]['quantity']++;
    } else {
        // Ürün sepette yoksa ekle
        $_SESSION['cart'][$product_id] = array(
            'id' => $product_id,
            'name' => $product_name,
            'price' => $product_price,
            'image' => $product_image,
            'quantity' => 1
        );
    }
    
    // Sepet toplamını güncelle
    $_SESSION['cart_total'] += $product_price;
    
    // AJAX isteği ise JSON yanıt döndür
    if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        echo json_encode(array(
            'success' => true,
            'cart_count' => count($_SESSION['cart']),
            'cart_total' => $_SESSION['cart_total']
        ));
        exit;
    }
    
    // Normal istek ise ana sayfaya yönlendir
    header('Location: index.php');
    exit;
}

// Sepetten ürün kaldırma işlemi
if(isset($_POST['remove_from_cart'])) {
    $product_id = $_POST['product_id'];
    
    if(isset($_SESSION['cart'][$product_id])) {
        // Sepet toplamını güncelle
        $_SESSION['cart_total'] -= $_SESSION['cart'][$product_id]['price'] * $_SESSION['cart'][$product_id]['quantity'];
        
        // Ürünü sepetten kaldır
        unset($_SESSION['cart'][$product_id]);
    }
    
    // AJAX isteği ise JSON yanıt döndür
    if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        echo json_encode(array(
            'success' => true,
            'cart_count' => count($_SESSION['cart']),
            'cart_total' => $_SESSION['cart_total']
        ));
        exit;
    }
    
    // Normal istek ise ana sayfaya yönlendir
    header('Location: index.php');
    exit;
}

// Favorilere ürün ekleme işlemi
if(isset($_POST['add_to_favorites'])) {
    $product_id = $_POST['product_id'];
    $product_name = $_POST['product_name'];
    $product_price = $_POST['product_price'];
    $product_image = $_POST['product_image'];
    
    // Ürün favorilerde var mı kontrol et
    if(!isset($_SESSION['favorites'][$product_id])) {
        // Ürün favorilerde yoksa ekle
        $_SESSION['favorites'][$product_id] = array(
            'id' => $product_id,
            'name' => $product_name,
            'price' => $product_price,
            'image' => $product_image
        );
        
        // Favoriler sayısını güncelle
        $_SESSION['favorites_count'] = count($_SESSION['favorites']);
    }
    
    // AJAX isteği ise JSON yanıt döndür
    if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        echo json_encode(array(
            'success' => true,
            'favorites_count' => $_SESSION['favorites_count']
        ));
        exit;
    }
    
    // Normal istek ise ana sayfaya yönlendir
    header('Location: index.php');
    exit;
}

// Favorilerden ürün kaldırma işlemi
if(isset($_POST['remove_from_favorites'])) {
    $product_id = $_POST['product_id'];
    
    if(isset($_SESSION['favorites'][$product_id])) {
        // Ürünü favorilerden kaldır
        unset($_SESSION['favorites'][$product_id]);
        
        // Favoriler sayısını güncelle
        $_SESSION['favorites_count'] = count($_SESSION['favorites']);
    }
    
    // AJAX isteği ise JSON yanıt döndür
    if(!empty($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
        echo json_encode(array(
            'success' => true,
            'favorites_count' => $_SESSION['favorites_count']
        ));
        exit;
    }
    
    // Normal istek ise ana sayfaya yönlendir
    header('Location: index.php');
    exit;
}

// Kategorileri veritabanından çek
$kategoriler = array();
$sql = "SELECT * FROM kategoriler ORDER BY id ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $kategoriler[] = $row;
    }
}

// Slider veritabanından çek
$sliders = array();
$sql = "SELECT * FROM slider ORDER BY sira ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $sliders[] = $row;
    }
}

// Ürünleri veritabanından çek
$urunler = array();
$sql = "SELECT urunler.*, kategoriler.ad as kategori_adi FROM urunler 
        LEFT JOIN kategoriler ON urunler.kategori_id = kategoriler.id 
        ORDER BY urunler.id ASC";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        $urunler[] = $row;
    }
}

// Kategori filtreleme
$kategori_id = isset($_GET['kategori']) ? intval($_GET['kategori']) : 0;

// Filtrelenmiş ürünleri çek
$filtrelenmis_urunler = array();
if ($kategori_id > 0) {
    $sql = "SELECT urunler.*, kategoriler.ad as kategori_adi FROM urunler 
            LEFT JOIN kategoriler ON urunler.kategori_id = kategoriler.id 
            WHERE urunler.kategori_id = $kategori_id
            ORDER BY urunler.id ASC";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while($row = $result->fetch_assoc()) {
            $filtrelenmis_urunler[] = $row;
        }
    }
} else {
    $filtrelenmis_urunler = $urunler;
}
?>
<!DOCTYPE html>
<html lang="tr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sarsılmaz</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: Arial, sans-serif;
        }
        
        .container {
            max-width: 1200px;
            margin: 0 auto;
        }
        
        .top-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 15px 0;
            border-bottom: 1px solid #eee;
        }
        
        .logo img {
            height: 20px;
        }
        
        .main-nav {
            display: flex;
            align-items: center;
            gap: 20px;
        }
        
        .main-nav a {
            text-decoration: none;
            color: #333;
            font-weight: 500;
            font-size: 16px;
        }
        
        .main-nav a:hover {
            color: #0066cc;
        }
        
        .right-nav {
            display: flex;
            align-items: center;
            gap: 10px;
        }
        
        .lang-selector {
            padding: 5px 10px;
            border: none;
            background: none;
            font-weight: bold;
        }
        
        .search-icon, .campaign-btn, .shop-btn, .supplier-btn, .favorites-btn {
            padding: 8px 15px;
            border-radius: 5px;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 5px;
        }
        
        .search-icon {
            background: none;
            border: none;
            font-size: 20px;
            color: #666;
        }
        
        .campaign-btn {
            background-color: #1075D1;
            color: white;
        }
        
        .shop-btn, .favorites-btn {
            background-color: #E5141D;
            color: white;
        }
        
        .supplier-btn {
            background-color: #234687;
            color: white;
        }
        
        .categories {
            display: flex;
            justify-content: space-between;
            padding: 20px 0;
            border-bottom: 1px solid #eee;
            flex-wrap: wrap;
        }
        
        .category-item {
            display: flex;
            align-items: center;
            gap: 10px;
            text-decoration: none;
            color: #333;
            font-weight: 500;
            margin-bottom: 10px;
        }
        
        .category-icon {
            width: 40px;
            height: 40px;
            background-color: #f5f5f5;
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        
        .category-icon img {
            width: 24px;
            height: 24px;
        }

        /* Cart Styles */
        .cart-wrapper {
            position: relative;
        }

        .cart-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #E5141D;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
        }

        .cart-dropdown {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            width: 300px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
            padding: 15px;
        }

        .cart-items {
            max-height: 300px;
            overflow-y: auto;
        }

        .cart-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }

        .cart-total {
            margin-top: 15px;
            padding: 10px 0;
            border-top: 1px solid #eee;
            display: flex;
            justify-content: space-between;
            font-weight: bold;
        }

        .btn-checkout {
            width: 100%;
            padding: 10px;
            background: #234687;
            color: white;
            border: none;
            border-radius: 4px;
            margin-top: 10px;
            cursor: pointer;
        }

        .btn-checkout:hover {
            background: #1a3567;
        }

        .btn-remove {
            background: none;
            border: none;
            cursor: pointer;
            padding: 0 5px;
        }
        
        /* Favorites Styles */
        .favorites-wrapper {
            position: relative;
        }

        .favorites-count {
            position: absolute;
            top: -8px;
            right: -8px;
            background: #E5141D;
            color: white;
            border-radius: 50%;
            padding: 2px 6px;
            font-size: 12px;
        }

        .favorites-dropdown {
            display: none;
            position: absolute;
            right: 0;
            top: 100%;
            width: 300px;
            background: white;
            border: 1px solid #ddd;
            border-radius: 4px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            z-index: 1000;
            padding: 15px;
        }

        .favorites-items {
            max-height: 300px;
            overflow-y: auto;
        }

        .favorite-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 10px 0;
            border-bottom: 1px solid #eee;
        }
        
        .btn-add-to-cart {
            padding: 5px 10px;
            background: #234687;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 12px;
            margin-right: 5px;
        }
        
        .btn-add-to-cart:hover {
            background: #1a3567;
        }
        
        /* Carousel Styles */
        .carousel {
            position: relative;
            width: 100%;
            height: 400px;
            overflow: hidden;
            margin: 20px 0;
        }
        
        .carousel-inner {
            display: flex;
            transition: transform 0.5s ease;
            height: 100%;
        }
        
        .carousel-item {
            min-width: 100%;
            height: 100%;
        }
        
        .carousel-item img {
            width: 100%;
            height: 100%;
            object-fit: cover;
        }
        
        .carousel-control {
            position: absolute;
            top: 50%;
            transform: translateY(-50%);
            width: 50px;
            height: 50px;
            background-color: rgba(0,0,0,0.5);
            border-radius: 50%;
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-size: 24px;
            cursor: pointer;
            z-index: 10;
        }
        
        .carousel-control.prev {
            left: 20px;
        }
        
        .carousel-control.next {
            right: 20px;
        }
        
        .carousel-indicators {
            position: absolute;
            bottom: 20px;
            left: 50%;
            transform: translateX(-50%);
            display: flex;
            gap: 10px;
        }
        
        .carousel-indicator {
            width: 12px;
            height: 12px;
            border-radius: 50%;
            background-color: rgba(255,255,255,0.5);
            cursor: pointer;
        }
        
        .carousel-indicator.active {
            background-color: white;
        }
        
        /* Product Grid Styles */
        .products-section {
            padding: 40px 0;
        }
        
        .section-title {
            font-size: 24px;
            margin-bottom: 20px;
            color: #234687;
        }
        
        .product-grid {
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 20px;
        }
        
        @media (max-width: 992px) {
            .product-grid {
                grid-template-columns: repeat(3, 1fr);
            }
        }
        
        @media (max-width: 768px) {
            .product-grid {
                grid-template-columns: repeat(2, 1fr);
            }
        }
        
        @media (max-width: 576px) {
            .product-grid {
                grid-template-columns: 1fr;
            }
        }
        
        .product-card {
            border: 1px solid #eee;
            border-radius: 8px;
            overflow: hidden;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            position: relative;
        }
        
        .product-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0,0,0,0.1);
        }
        
        .product-image {
            height: 200px;
            width: 100%;
            overflow: hidden;
        }
        
        .product-image img {
            width: 100%;
            height: 100%;
            object-fit: cover;
            transition: transform 0.3s ease;
        }
        
        .product-card:hover .product-image img {
            transform: scale(1.05);
        }
        
        .product-details {
            padding: 15px;
        }
        
        .product-title {
            font-size: 16px;
            font-weight: 500;
            margin-bottom: 10px;
            color: #333;
        }
        
        .product-price {
            font-size: 18px;
            font-weight: 700;
            color: #234687;
            margin-bottom: 15px;
        }
        
        .product-actions {
            display: flex;
            gap: 10px;
        }
        
        .add-to-cart {
    background-color: #E5141D; /* Kırmızı arka plan */
    color: white; /* Beyaz yazı */
    font-size: 16px; /* Yazı boyutu */
    font-weight: 600; /* Yazı kalınlığı */
    padding: 12px 20px; /* İç boşluk */
    border: none; /* Kenarlık yok */
    border-radius: 6px; /* Yuvarlatılmış köşeler */
    cursor: pointer; /* İmleç değişimi */
    transition: all 0.3s ease; /* Hover geçiş efekti */
    box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1); /* Hafif gölge */
    text-align: center; /* Metni ortala */
}
         .add-to-favorites {
            flex: 1;
            padding: 10px;
            color: white;
            border: none;
            border-radius: 4px;
            font-weight: 500;
            cursor: pointer;
            transition: background-color 0.3s ease;
            text-align: center;
        }
        
        .add-to-cart {
            background-color: #E5141D;
        }
        
       .add-to-cart:hover {
    background-color: #c41319; /* Hover rengi */
    box-shadow: 0 6px 8px rgba(0, 0, 0, 0.2); /* Hover gölgesi */
    transform: scale(1.05); /* Butonu hafif büyütme */

        }
        
        .add-to-favorites {
            background-color: #1075D1;
        }
        
        .add-to-favorites:hover {
            background-color: #0d63a9;
        }

        /* User menu styles */
        .user-menu {
            position: relative;
        }
        
        .dropdown-content {
            display: none;
            position: absolute;
            right: 0;
            background-color: white;
            min-width: 160px;
            box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
            z-index: 1;
            border-radius: 4px;
            margin-top: 5px;
        }
        
        .dropdown-content a {
            color: black;
            padding: 12px 16px;
            text-decoration: none;
            display: block;
            font-size: 14px;
        }
        
        .dropdown-content a:hover {
            background-color: #f1f1f1;
        }
        
        .user-menu:hover .dropdown-content {
            display: block;
        }

        /* Footer styles */
        .footer {
            background-color: #234687;
            color: white;
            padding: 40px 20px;
        }

        .footer-container {
            display: flex;
            justify-content: space-between;
            max-width: 1200px;
            margin: 0 auto;
            flex-wrap: wrap;
        }

        .footer-links, .footer-contact, .footer-social {
            flex: 1;
            margin-right: 20px;
            margin-bottom: 20px;
            min-width: 250px;
        }

        .footer-links h4, .footer-contact h4, .footer-social h4 {
            margin-bottom: 10px;
        }

        .footer-links a, .footer-social a {
            color: white;
            text-decoration: none;
            display: block;
            margin: 5px 0;
        }

        .footer-links a:hover, .footer-social a:hover {
            text-decoration: underline;
        }

        .footer-bottom {
            text-align: center;
            margin-top: 20px;
            font-size: 14px;
        }
        
        /* Notification style */
        .notification {
            position: fixed;
            top: 20px;
            right: 20px;
            background-color: #234687;
            color: white;
            padding: 15px 20px;
            border-radius: 5px;
            box-shadow: 0 3px 10px rgba(0,0,0,0.2);
            z-index: 1100;
            opacity: 0;
            transform: translateY(-20px);
            transition: opacity 0.3s ease, transform 0.3s ease;
        }
        
        .notification.show {
            opacity: 1;
            transform: translateY(0);
        }
        
        /* Kategori filtreleme stilleri */
        .category-filter {
            margin: 20px 0;
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
        }
        
        .category-filter a {
            padding: 8px 15px;
            background-color: #f5f5f5;
            border-radius: 4px;
            text-decoration: none;
            color: #333;
            transition: background-color 0.3s ease;
        }
        
        .category-filter a:hover, .category-filter a.active {
            background-color: #234687;
            color: white;
        }
    </style>
</head>
<body>
    <!-- Bildirim elementi -->
    <div id="notification" class="notification"></div>
    
    <div class="container">
        <!-- Header Navigation -->
        <div class="top-header">
            <div class="logo">
               <a href="index.php"><img src="http://emirsabanci.rf.gd/sarsilmaz/img/logo.png" alt="Sarsilmaz"></a>
            </div>
            
            <div class="main-nav">
                <a href="index.php">Ana Sayfa</a>
                <a href="#">Kurumsal</a>
                <a href="#">Üretim</a>
                <a href="#">Satış Destek</a>
                <a href="#">Yetkili Servisler</a>
                <a href="#">Medya</a>
                <a href="#">İletişim</a>
            </div>
            
            <div class="right-nav">
                <button class="lang-selector">EN</button>
                <button class="search-icon">🔍</button>
                
                <!-- Favoriler butonu -->
                <div class="favorites-wrapper">
                    <a href="#" class="favorites-btn" id="favoritesButton">
                        <span❤️</span> Favoriler
                        <span class="favorites-count" id="favoritesCount"><?php echo count($_SESSION['favorites']); ?></span>
                    </a>
                    
                    <!-- Favoriler dropdown -->
                    <div class="favorites-dropdown" id="favoritesDropdown">
                        <div class="favorites-items" id="favoritesItems">
                            <?php if(count($_SESSION['favorites']) > 0): ?>
                                <?php foreach($_SESSION['favorites'] as $item): ?>
                                <div class="favorite-item">
                                    <div>
                                        <div><?php echo $item['name']; ?></div>
                                        <div><?php echo number_format($item['price'], 2); ?> TL</div>
                                    </div>
                                    <div>
                                        <form method="post" action="index.php" style="display: inline;">
                                            <input type="hidden" name="product_id" value="<?php echo $item['id']; ?>">
                                            <input type="hidden" name="product_name" value="<?php echo $item['name']; ?>">
                                            <input type="hidden" name="product_price" value="<?php echo $item['price']; ?>">
                                            <input type="hidden" name="product_image" value="<?php echo $item['image']; ?>">
                                            <button type="submit" name="add_to_cart" class="btn-add-to-cart">Sepete Ekle</button>
                                        </form>
                                        <button class="btn-remove btn-remove-favorite" data-id="<?php echo $item['id']; ?>">❌</button>
                                    </div>
                                </div>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <div class="empty-favorites">Favori listeniz boş.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
                <!-- Sepet butonu -->
                <div class="cart-wrapper">
                    <a href="#" class="shop-btn" id="cartButton">
                        <span>🛒</span> Sepet
                        <span class="cart-count" id="cartCount"><?php echo count($_SESSION['cart']); ?></span>
                    </a>
                    
                    <!-- Sepet dropdown -->
                    <div class="cart-dropdown" id="cartDropdown">
                        <div class="cart-items" id="cartItems">
                            <?php if(count($_SESSION['cart']) > 0): ?>
                                <?php foreach($_SESSION['cart'] as $item): ?>
                                <div class="cart-item">
                                    <div>
                                        <div><?php echo $item['name']; ?></div>
                                        <div><?php echo $item['quantity']; ?> x <?php echo number_format($item['price'], 2); ?> TL</div>
                                    </div>
                                    <button class="btn-remove" data-id="<?php echo $item['id']; ?>">❌</button>
                                </div>
                                <?php endforeach; ?>
                                <div class="cart-total">
                                    <span>Toplam:</span>
                                    <span><?php echo number_format($_SESSION['cart_total'], 2); ?> TL</span>
                                </div>
                                <button class="btn-checkout">Sepeti Onayla</button>
                            <?php else: ?>
                                <div class="empty-cart">Sepetinizde ürün bulunmamaktadır.</div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                
               <?php if($isLoggedIn): ?>
<div class="user-menu">
    <div class="supplier-btn">
      <span>👤</span> <?php echo htmlspecialchars($_SESSION["isim"] . " " . $_SESSION["soyisim"]); ?>

    </div>
    <div class="dropdown-content">
        <a href="profile.php">Hesabım</a>
        <a href="orders.php">Siparişlerim</a>
        <a href="logout.php">Çıkış Yap</a>
    </div>
</div>
<?php else: ?>
<a href="login.php" class="supplier-btn">
    <span>🔄</span> Giriş Yap
</a>
<?php endif; ?>
            </div>
        </div>
        
        <!-- Categories -->
        <div class="categories">
            <?php foreach($kategoriler as $kategori): ?>
            <a href="index.php?kategori=<?php echo $kategori['id']; ?>" class="category-item">
                <div class="category-icon">
                    <img src="<?php echo $kategori['icon']; ?>" alt="<?php echo $kategori['ad']; ?>">
                </div>
                <span><?php echo $kategori['ad']; ?></span>
            </a>
            <?php endforeach; ?>
        </div>
        
        <!-- Slider -->
        <div class="carousel">
            <div class="carousel-inner">
                <?php foreach($sliders as $index => $slider): ?>
                <div class="carousel-item <?php echo $index === 0 ? 'active' : ''; ?>">
                    <img src="<?php echo $slider['resim']; ?>" alt="<?php echo $slider['baslik']; ?>">
                </div>
                <?php endforeach; ?>
            </div>
            <div class="carousel-control prev">❮</div>
            <div class="carousel-control next">❯</div>
            <div class="carousel-indicators">
                <?php foreach($sliders as $index => $slider): ?>
                <div class="carousel-indicator <?php echo $index === 0 ? 'active' : ''; ?>" data-index="<?php echo $index; ?>"></div>
                <?php endforeach; ?>
            </div>
        </div>
        
        <!-- Kategori Filtreleme -->
        <div class="category-filter">
            <a href="index.php" class="<?php echo $kategori_id === 0 ? 'active' : ''; ?>">Tümü</a>
            <?php foreach($kategoriler as $kategori): ?>
            <a href="index.php?kategori=<?php echo $kategori['id']; ?>" class="<?php echo $kategori_id === $kategori['id'] ? 'active' : ''; ?>">
                <?php echo $kategori['ad']; ?>
            </a>
            <?php endforeach; ?>
        </div>
        
        <!-- Products Section -->
        <div class="products-section">
            <h2 class="section-title">
                <?php 
                if($kategori_id > 0) {
                    foreach($kategoriler as $kategori) {
                        if($kategori['id'] == $kategori_id) {
                            echo $kategori['ad'];
                            break;
                        }
                    }
                } else {
                    echo "Tüm Ürünler";
                }
                ?>
            </h2>
            <div class="product-grid">
                <?php foreach($filtrelenmis_urunler as $urun): ?>
                <div class="product-card">
                    <div class="product-image">
                        <img src="<?php echo $urun['resim']; ?>" alt="<?php echo $urun['ad']; ?>">
                    </div>
                    <div class="product-details">
                        <h3 class="product-title"><?php echo $urun['ad']; ?></h3>
                        <div class="product-price"><?php echo number_format($urun['fiyat'], 2); ?> TL</div>
                        <div class="product-actions">
                            <form method="post" action="index.php" class="add-to-cart">
                                <input type="hidden" name="product_id" value="<?php echo $urun['id']; ?>">
                                <input type="hidden" name="product_name" value="<?php echo $urun['ad']; ?>">
                                <input type="hidden" name="product_price" value="<?php echo $urun['fiyat']; ?>">
                                <input type="hidden" name="product_image" value="<?php echo $urun['resim']; ?>">
                                <div class="product-actions">
    <button type="submit" name="add_to_cart" class="add-to-cart">Sepete Ekle</button>
</div>

                            </form>
                            <button class="add-to-favorites" 
                                data-id="<?php echo $urun['id']; ?>" 
                                data-name="<?php echo $urun['ad']; ?>" 
                                data-price="<?php echo $urun['fiyat']; ?>" 
                                data-image="<?php echo $urun['resim']; ?>">
                                Favorilere Ekle
                            </button>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
    
    <!-- Footer -->
    <div class="footer">
        <div class="footer-container">
            <div class="footer-links">
                <h4>Hızlı Bağlantılar</h4>
                <a href="index.php">Ana Sayfa</a>
                <a href="#">Hakkımızda</a>
                <a href="#">Ürünler</a>
                <a href="#">Bayi Satış Noktaları</a>
                <a href="#">İletişim</a>
            </div>
            <div class="footer-contact">
                <h4>İletişim</h4>
                <p>Adres: Organize Sanayi Bölgesi, 1. Cadde, No:1, 34000</p>
                <p>Telefon: +90 212 123 45 67</p>
                <p>E-posta: info@sarsilmaz.com</p>
            </div>
            <div class="footer-social">
                <h4>Sosyal Medya</h4>
                <a href="#">Facebook</a>
                <a href="#">Twitter</a>
                <a href="#">Instagram</a>
                <a href="#">YouTube</a>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?php echo date('Y'); ?> Sarsılmaz. Tüm hakları saklıdır.</p>
        </div>
    </div>
    
    <!-- AJAX işlemleri için JavaScript -->
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            // Sepet butonuna tıklama işlemi
            const cartButton = document.getElementById('cartButton');
            const cartDropdown = document.getElementById('cartDropdown');
            
            if(cartButton && cartDropdown) {
                cartButton.addEventListener('click', function(e) {
                    e.preventDefault();
                    cartDropdown.style.display = cartDropdown.style.display === 'block' ? 'none' : 'block';
                });
                
                // Dışarı tıklandığında sepet menüsünü kapat
                document.addEventListener('click', function(e) {
                    if (!cartButton.contains(e.target) && !cartDropdown.contains(e.target)) {
                        cartDropdown.style.display = 'none';
                    }
                });
            }
            
            // Favoriler butonuna tıklama işlemi
            const favoritesButton = document.getElementById('favoritesButton');
            const favoritesDropdown = document.getElementById('favoritesDropdown');
            
            if(favoritesButton && favoritesDropdown) {
                favoritesButton.addEventListener('click', function(e) {
                    e.preventDefault();
                    favoritesDropdown.style.display = favoritesDropdown.style.display === 'block' ? 'none' : 'block';
                });
                
                // Dışarı tıklandığında favori menüsünü kapat
                document.addEventListener('click', function(e) {
                    if (!favoritesButton.contains(e.target) && !favoritesDropdown.contains(e.target)) {
                        favoritesDropdown.style.display = 'none';
                    }
                });
            }
            
            // Sepetten kaldırma düğmelerine tıklama işlemi
            const removeButtons = document.querySelectorAll('.cart-item .btn-remove');
            
            removeButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.getAttribute('data-id');
                    
                    // AJAX isteği ile sepetten kaldır
                    const xhr = new XMLHttpRequest();
                    xhr.open('POST', 'index.php', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
                    xhr.onload = function() {
                        if (this.status === 200) {
                            try {
                                const response = JSON.parse(this.responseText);
                                
                                if(response.success) {
                                    // Sayfa yenilemeden sepet öğesini kaldır
                                    const cartItem = button.closest('.cart-item');
                                    if(cartItem) {
                                        cartItem.remove();
                                    }
                                    
                                    // Sepet sayısını güncelle
                                    const cartCount = document.getElementById('cartCount');
                                    if(cartCount) {
                                        cartCount.textContent = response.cart_count;
                                    }
                                    
                                    // Sepet toplamını güncelle
                                    const cartTotal = document.querySelector('.cart-total span:last-child');
                                    if(cartTotal) {
                                        cartTotal.textContent = parseFloat(response.cart_total).toFixed(2) + ' TL';
                                    }
                                    
                                    // Sepet boş ise mesaj göster
                                    if(response.cart_count === 0) {
                                        const cartItems = document.getElementById('cartItems');
                                        if(cartItems) {
                                            cartItems.innerHTML = '<div class="empty-cart">Sepetinizde ürün bulunmamaktadır.</div>';
                                        }
                                    }
                                    
                                    // Bildirim göster
                                    showNotification('Ürün sepetten kaldırıldı!');
                                }
                            } catch(e) {
                                console.error('JSON parsing error:', e);
                            }
                        }
                    };
                    xhr.send('remove_from_cart=1&product_id=' + productId);
                });
            });
            
            // Favorilerden kaldırma düğmelerine tıklama işlemi
            const removeFavoriteButtons = document.querySelectorAll('.favorite-item .btn-remove-favorite');
            
            removeFavoriteButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.getAttribute('data-id');
                    
                    // AJAX isteği ile favorilerden kaldır
                    const xhr = new XMLHttpRequest();
                    xhr.open('POST', 'index.php', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
                    xhr.onload = function() {
                        if (this.status === 200) {
                            try {
                                const response = JSON.parse(this.responseText);
                                
                                if(response.success) {
                                    // Sayfa yenilemeden favori öğesini kaldır
                                    const favoriteItem = button.closest('.favorite-item');
                                    if(favoriteItem) {
                                        favoriteItem.remove();
                                    }
                                    
                                    // Favoriler sayısını güncelle
                                    const favoritesCount = document.getElementById('favoritesCount');
                                    if(favoritesCount) {
                                        favoritesCount.textContent = response.favorites_count;
                                    }
                                    
                                    // Favoriler boş ise mesaj göster
                                    if(response.favorites_count === 0) {
                                        const favoritesItems = document.getElementById('favoritesItems');
                                        if(favoritesItems) {
                                            favoritesItems.innerHTML = '<div class="empty-favorites">Favori listeniz boş.</div>';
                                        }
                                    }
                                    
                                    // Bildirim göster
                                    showNotification('Ürün favorilerden kaldırıldı!');
                                }
                            } catch(e) {
                                console.error('JSON parsing error:', e);
                            }
                        }
                    };
                    xhr.send('remove_from_favorites=1&product_id=' + productId);
                });
            });
            
            // Favorilere ekleme düğmelerine tıklama işlemi
            const addToFavoritesButtons = document.querySelectorAll('.add-to-favorites');
            
            addToFavoritesButtons.forEach(button => {
                button.addEventListener('click', function() {
                    const productId = this.getAttribute('data-id');
                    const productName = this.getAttribute('data-name');
                    const productPrice = this.getAttribute('data-price');
                    const productImage = this.getAttribute('data-image');
                    
                    // AJAX isteği ile favorilere ekle
                    const xhr = new XMLHttpRequest();
                    xhr.open('POST', 'index.php', true);
                    xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
                    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
                    xhr.onload = function() {
                        if (this.status === 200) {
                            try {
                                const response = JSON.parse(this.responseText);
                                
                                if(response.success) {
                                    // Favoriler sayısını güncelle
                                    const favoritesCount = document.getElementById('favoritesCount');
                                    if(favoritesCount) {
                                        favoritesCount.textContent = response.favorites_count;
                                    }
                                    
                                    // Favoriler dropdown'ı güncelle (sayfayı yenilemeden)
                                    updateFavoritesDropdown();
                                    
                                    // Bildirim göster
                                    showNotification('Ürün favorilere eklendi!');
                                }
                            } catch(e) {
                                console.error('JSON parsing error:', e);
                            }
                        }
                    };
                    xhr.send(`add_to_favorites=1&product_id=${productId}&product_name=${encodeURIComponent(productName)}&product_price=${productPrice}&product_image=${encodeURIComponent(productImage)}`);
                });
            });
            
            // Favoriler dropdown'ı güncelleme fonksiyonu
            function updateFavoritesDropdown() {
                // Sayfayı yenilemeden favorileri güncelle
                location.reload();
            }
            
            // Bildirim gösterme fonksiyonu
            function showNotification(message) {
                const notification = document.getElementById('notification');
                if(notification) {
                    notification.textContent = message;
                    notification.classList.add('show');
                    
                    // 3 saniye sonra bildirimi kaldır
                    setTimeout(function() {
                        notification.classList.remove('show');
                    }, 3000);
                }
            }
            
            // Slider işlemleri
            const carousel = document.querySelector('.carousel');
            const carouselInner = document.querySelector('.carousel-inner');
            const items = document.querySelectorAll('.carousel-item');
            const indicators = document.querySelectorAll('.carousel-indicator');
            const prevControl = document.querySelector('.carousel-control.prev');
            const nextControl = document.querySelector('.carousel-control.next');
            
            if(carousel && carouselInner && items.length > 0) {
                let currentIndex = 0;
                const totalItems = items.length;
                
                // İlk slaydı aktif yap
                items[0].classList.add('active');
                
                // Slayt gösterisi otomatik değiştirme
                let interval = setInterval(moveToNextSlide, 5000);
                
                // Sonraki slayta geç
                function moveToNextSlide() {
                    currentIndex = (currentIndex + 1) % totalItems;
                    updateCarousel();
                }
                
                // Önceki slayta geç
                function moveToPrevSlide() {
                    currentIndex = (currentIndex - 1 + totalItems) % totalItems;
                    updateCarousel();
                }
                
                // Carousel'ı güncelle
                function updateCarousel() {
                    carouselInner.style.transform = `translateX(-${currentIndex * 100}%)`;
                    
                    // Aktif göstergeyi güncelle
                    indicators.forEach((indicator, index) => {
                        if(index === currentIndex) {
                            indicator.classList.add('active');
                        } else {
                            indicator.classList.remove('active');
                        }
                    });
                }
                
                // Önceki slayt butonuna tıklama
                if(prevControl) {
                    prevControl.addEventListener('click', function() {
                        clearInterval(interval);
                        moveToPrevSlide();
                        interval = setInterval(moveToNextSlide, 5000);
                    });
                }
                
                // Sonraki slayt butonuna tıklama
                if(nextControl) {
                    nextControl.addEventListener('click', function() {
                        clearInterval(interval);
                        moveToNextSlide();
                        interval = setInterval(moveToNextSlide, 5000);
                    });
                }
                
                // Göstergelere tıklama
                indicators.forEach((indicator, index) => {
                    indicator.addEventListener('click', function() {
                        clearInterval(interval);
                        currentIndex = index;
                        updateCarousel();
                        interval = setInterval(moveToNextSlide, 5000);
                    });
                });
            }
        });
    </script>
</body>
</html>
